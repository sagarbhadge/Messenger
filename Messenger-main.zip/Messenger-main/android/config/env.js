export const env = {
  GQL_SERVER: 'https://relatedchat.io:4000',
  API_URL: 'https://relatedchat.io:4001',
  LINK_CLOUD_STICKER: 'https://relatedchat.io/stickers',
  MESSAGES_PER_PAGE: 30,
};
