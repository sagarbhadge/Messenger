export const GQL_SERVER_URL =
  process.env.GQL_SERVER_URL || "http://gqlserver:4000";
